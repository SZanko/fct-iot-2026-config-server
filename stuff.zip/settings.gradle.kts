rootProject.name = "configserver"
